export interface JWTUser {
  id: string;
  name: string;
  iat: number;
  exp: number;
}
