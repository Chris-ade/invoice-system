import { res } from "@/lib/auth";
import db from "@/lib/prisma";
import { withAuthParams } from "@/lib/withAuth";
import { NextRequest } from "next/server";

export const GET = withAuthParams<{ id: string }>(
  async (req: NextRequest, context, user) => {
    try {
      const { id } = context.params;

      // Get invoice by ID
      const invoice = await db.invoice.findUnique({
        where: { id: parseInt(id) },
        include: {
          items: true,
          cashier: { select: { id: true, name: true } },
        },
      });

      if (!invoice) {
        return res({ success: false, message: "Invoice not found" }, 404);
      }

      const formattedInvoice = {
        id: invoice.id,
        invoiceNumber: invoice.invoiceNumber,
        customerName: invoice.customerName,
        cashierName: invoice.cashier.name,
        invoiceDate: invoice.invoiceDate,
        total: invoice.total,
        items: invoice.items.map((item) => ({
          id: item.id,
          invoiceId: item.invoiceId,
          description: item.description,
          quantity: item.quantity,
          amount: item.amount,
          total: item.total,
        })),
      };

      return res({ success: true, data: formattedInvoice });
    } catch (error: any) {
      console.error(error);
      return res(
        {
          success: false,
          message: error.message || "Failed to create invoice",
        },
        500
      );
    }
  }
);
