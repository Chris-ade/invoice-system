import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Copy, Edit, MoreHorizontal, Printer, Trash2 } from "lucide-react";
import React from "react";

import { ColumnDef } from "@tanstack/react-table";
import { Invoice, InvoiceColumns } from "@/types/invoice";
import { useRouter } from "next/navigation";
import { useToast } from "@/hooks/use-toast";

export const columns = (
  onDelete: (id: string) => void,
  onUpdate: (invoice: InvoiceColumns) => void
): ColumnDef<InvoiceColumns>[] => [
  {
    accessorKey: "customerName",
    header: "Customer Name",
  },
  {
    accessorKey: "invoiceNumber",
    header: "Invoice Number",
  },
  {
    accessorKey: "cashierName",
    header: "Cashier Name",
    cell: ({ row }) => {
      return row.original.cashierName.toUpperCase();
    },
  },
  {
    accessorKey: "invoiceDate",
    header: "Created date",
    cell: ({ row }) => {
      return new Date(row.getValue("invoiceDate")).toLocaleDateString("en-GB");
    },
  },
  {
    header: "Actions",
    id: "actions",
    enableHiding: false,
    cell: ({ row }) => {
      const invoice = row.original;
      const router = useRouter();
      const { toastSuccess } = useToast();
      const [open, setOpen] = React.useState(false);
      const [editOpen, setEditOpen] = React.useState(false);

      const handlePrint = (invoice: InvoiceColumns) => {
        router.replace(`/invoices/${invoice.id}/print`);
      };

      return (
        <>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem
                onClick={() => {
                  navigator.clipboard.writeText(invoice.invoiceNumber);
                  toastSuccess("Invoice number copied to clipboard!");
                }}
              >
                <Copy className="w-4 h-4" />
                Copy invoice number
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setOpen(true)}>
                <Trash2 className="w-4 h-4" /> Delete invoice
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setEditOpen(true)}>
                <Edit className="w-4 h-4" />
                Edit invoice
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handlePrint(invoice)}>
                <Printer className="w-4 h-4" />
                Print invoice
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </>
      );
    },
  },
];
